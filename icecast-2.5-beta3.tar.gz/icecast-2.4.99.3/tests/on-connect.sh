#!/bin/bash
touch "on-connect-success"
exit 0
